﻿import { Component } from '@angular/core';
import{PaymentService} from './payment.service';
import {Router} from '@angular/router';

@Component({
    selector: 'app',
    templateUrl: 'app.component.html'
})

export class AppComponent {
    constructor(private router: Router, private accountService: PaymentService){}

    proStore:any;
  
    addData(){
        this.accountService.sendData(this.proStore).subscribe();
    }

 }